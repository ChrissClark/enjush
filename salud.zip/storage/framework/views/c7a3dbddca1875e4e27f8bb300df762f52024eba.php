<div class="form-floating mb-3">
  <input type="text" name="abreviacion" class="form-control" id="Abreviacion" placeholder="Abreviacion" maxlength="50" value="<?php echo e($estado->abreviacion ?? old('abreviacion')); ?>">
  <label for="Abreviacion">Abreviacion</label>
</div>
<?php $__errorArgs = ['abreviacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="text-center mt-2">
    <button class="btn btn-outline-primary btn-sm"><?php echo e(empty($estado) ? "Crear" : "Actualizar"); ?></button>
</div>
<?php echo csrf_field(); ?><?php /**PATH /var/www/html/salud/salud/resources/views/formEstado.blade.php ENDPATH**/ ?>