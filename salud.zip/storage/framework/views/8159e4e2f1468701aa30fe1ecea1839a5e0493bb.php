<div class="form-floating mb-3">
  <select class="form-select" name="idSustancia" id="Sustancia" aria-label="Selecciona una sustancia">
    <?php $__currentLoopData = $sustancias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sustancia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($sustancia->id == $matriz->idSustancia): ?>
        <option value="<?php echo e($sustancia->id); ?>" selected><?php echo e($sustancia->nombre); ?></option>
      <?php else: ?>
        <option value="<?php echo e($sustancia->id); ?>"><?php echo e($sustancia->nombre); ?></option>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <label for="Sustancia">Selecciona una Sustancia</label>
</div>
<?php $__errorArgs = ['idSustancia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<input type="hidden" name="idEvaluacion" value="<?php echo e($evaluacion->id); ?>">
<?php ($mtzEvaluadora = json_decode($evaluacion->matriz)); ?>
<div class="form-floating mb-3">
  <select class="form-select" name="matriz" id="Matriz" aria-label="Selecciona un Estado">
    <?php $__currentLoopData = $mtzEvaluadora; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mValor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($mValor == $matriz->matriz): ?>
        <option value="<?php echo e($mValor); ?>" selected><?php echo e($mValor); ?></option>
      <?php else: ?>
        <option value="<?php echo e($mValor); ?>"><?php echo e($mValor); ?></option>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <label for="Matriz">Selecciona la Matriz a valorar</label>
</div>
<?php $__errorArgs = ['matriz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="form-floating mb-3">
  <input type="text" name="valor" class="form-control" id="Valor" placeholder="Valor" maxlength="45" value="<?php echo e($matriz->valor ?? old('valor')); ?>">
  <label for="Valor">Valor</label>
</div>
<?php $__errorArgs = ['Valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<div class="text-center mt-2">
  <button class="btn btn-outline-primary btn-sm"><?php echo e(empty($matriz->id) ? "Crear" : "Actualizar"); ?></button>
</div>
<?php echo csrf_field(); ?><?php /**PATH /var/www/html/salud/salud/resources/views/formMatrizAmbiental.blade.php ENDPATH**/ ?>