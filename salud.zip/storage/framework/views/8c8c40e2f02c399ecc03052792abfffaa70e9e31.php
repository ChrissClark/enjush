<?php $__env->startSection('title', 'Evaluadores'); ?>

<?php $__env->startSection('styles'); ?>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/2.2.2/css/dataTables.bootstrap5.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="d-flex justify-content-between align-items-center">
    <h1 class="">Evaluadores</h1>
    <div>
      <button class="btn btn-outline-primary btn-sm rounded" type="button" onclick="modalGet('<?php echo e(route('evaluadores.create')); ?>', 'Crear Evaluador')">Agregar Evaluador</button>
    </div>
  </div>
  <div class="table-responsive">
    <table id="Evaluadores" class="table table-striped" style="width:100%">
      <thead>
        <tr>
          <th>Nombre</th>
          <th class="text-center"># Evaluaciones</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $evaluadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($evaluador->nombre); ?></td>
            <td class="text-center"><?php echo e($evaluador->evaluaciones->count()); ?></td>
            <td class="text-center">
              <div class="d-flex justify-content-center">
                <button class="btn btn-outline-success btn-sm rounded me-2" type="button" onclick="modalGet('<?php echo e(route('evaluadores.edit', $evaluador->id)); ?>', 'Editar Evaluador')"><i class="far fa-edit"></i></button>
                <form action="<?php echo e(route('evaluadores.destroy', $evaluador->id)); ?>" class="float-right" method="post">
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-outline-danger btn-sm rounded"><i class="fas fa-trash-alt"></i></button>
                  <?php echo csrf_field(); ?>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
  <script src="https://cdn.datatables.net/2.2.2/js/dataTables.bootstrap5.js"></script>
  
  <script>
    $("#Evaluadores").DataTable();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/salud/salud/resources/views/evaluadores.blade.php ENDPATH**/ ?>