<div class="form-floating mb-3">
  <select class="form-select" name="idEvaluador" id="Evaluador" aria-label="Selecciona un evaluador">
    <?php $__currentLoopData = $evaluadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($evaluador->id == $evaluacion->idEvaluador): ?>
        <option value="<?php echo e($evaluador->id); ?>" selected><?php echo e($evaluador->nombre); ?></option>
      <?php else: ?>
        <option value="<?php echo e($evaluador->id); ?>"><?php echo e($evaluador->nombre); ?></option>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <label for="Evaluador">Selecciona un Evaluador</label>
</div>
<?php $__errorArgs = ['idEvaluador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<input type="hidden" name="idEmpresa" value="<?php echo e($idEmpresa); ?>">

<id class="">
  <div class="form-check-inline">
    <input class="form-check-input" type="radio" name="unidad" id="unidadkg" value="kg" checked>
    <label class="form-check-label" for="unidadkg">
      Kilogramos (kg)
    </label>
  </div>
  <div class="form-check-inline">
    <input class="form-check-input" type="radio" name="unidad" id="unidadt" value="t">
    <label class="form-check-label" for="unidadt">
      Toneladas (t)
    </label>
  </div>
  <?php $__errorArgs = ['unidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <span class="invalid-feedback" role="alert">
      <strong><?php echo e($message); ?></strong>
    </span>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</id>

<div class="form-floating my-3">
  <input type="text" name="año" class="form-control" id="Año" placeholder="Año" maxlength="45" value="<?php echo e($evaluacion->año ?? old('año')); ?>">
  <label for="Año">Año</label>
</div>
<?php $__errorArgs = ['año'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<?php ($mtzEvaluadora = $evaluacion->matriz ? implode(", ", json_decode($evaluacion->matriz)) : null); ?>
<div class="form-floating mb-3">
  <input type="text" name="matriz" class="form-control" id="Matriz" placeholder="Matriz a Evaluar" maxlength="45" value="<?php echo e($mtzEvaluadora ?? old('matriz')); ?>">
  <label for="Matriz">Matriz a Evaluar (separa con comas)</label>
</div>
<?php $__errorArgs = ['matriz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<div class="text-center mt-2">
  <button class="btn btn-outline-primary btn-sm"><?php echo e(empty($evaluacion->id) ? "Crear" : "Actualizar"); ?></button>
</div>
<?php echo csrf_field(); ?><?php /**PATH /var/www/html/salud/salud/resources/views/formEvaluacion.blade.php ENDPATH**/ ?>