<div class="form-floating mb-3">
  <input type="text" name="nombre" class="form-control" id="Nombre" placeholder="Nombre" maxlength="50" value="<?php echo e($municipio->nombre ?? old('nombre')); ?>">
  <label for="Nombre">Nombre</label>
</div>
<?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="form-floating mb-3">
  <select class="form-select" name="idEstado" id="Estado" aria-label="Selecciona un Estado">
    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($estado->id == $municipio->idEstado): ?>
        <option value="<?php echo e($estado->id); ?>" selected><?php echo e($estado->nombre); ?></option>
      <?php else: ?>
        <option value="<?php echo e($estado->id); ?>"><?php echo e($estado->nombre); ?></option>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <label for="Estado">Selecciona un Estado</label>
</div>
<?php $__errorArgs = ['idEstado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="form-floating mb-3">
  <input type="number" name="cve_mun" class="form-control" id="cve_mun" placeholder="cve_mun" value="<?php echo e($municipio->cve_mun ?? old('cve_mun')); ?>">
  <label for="cve_mun">Cve_mun</label>
</div>
<?php $__errorArgs = ['cve_mun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="form-floating mb-3">
  <input type="text" name="ageb" class="form-control" id="AGEB" placeholder="AGEB" maxlength="45" value="<?php echo e($municipio->ageb ?? old('ageb')); ?>">
  <label for="AGEB">AGEB</label>
</div>
<?php $__errorArgs = ['ageb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<div class="text-center mt-2">
  <button class="btn btn-outline-primary btn-sm"><?php echo e(empty($municipio->id) ? "Crear" : "Actualizar"); ?></button>
</div>
<?php echo csrf_field(); ?><?php /**PATH /var/www/html/salud/salud/resources/views/formMunicipio.blade.php ENDPATH**/ ?>