<div id="myModal" class="modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="color:#858796;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="myModalLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="formModal">
                <p>loading...</p>
            </div>
            <div class="modal-footer2">
            
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/html/salud/salud/resources/views/modal.blade.php ENDPATH**/ ?>