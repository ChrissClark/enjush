<?php $__env->startSection('title', 'Acerca de Nosotros'); ?>

<?php $__env->startSection('styles'); ?>
  <style>
    h1, h2, h3, h4, h5, h6 {
      color: #007bff;
    }
  </style>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="">Sustancias</h1>
  <!--  -->
  <section class="my-3">
    <h2 class="fs-3">Tabla de Sustancias</h2>
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">Nombre</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $sustancias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sustancia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($sustancia->nombre); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <table id="myTable" class="display">
      <thead>
        <tr>
          <th>Nombre</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $sustancias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sustancia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($sustancia->nombre); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

  </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scriptsTables'); ?>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script>$("#myTable").DataTable();</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/salud/salud/resources/views/sustancia.blade.php ENDPATH**/ ?>