<div class="form-floating mb-3">
  <input type="text" name="nombre" class="form-control" id="Nombre" placeholder="Nombre" maxlength="100" value="<?php echo e($subsector->nombre ?? old('nombre')); ?>">
  <label for="Nombre">Nombre</label>
</div>
<?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<div class="form-floating mb-3">
  <select id="Sector" name="idSector" class="form-select <?php $__errorArgs = ['idSector'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-label="Selecciona un Sector">
    <?php $__currentLoopData = $sectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($subsector->idSector && $sector->id == $subsector->sector->id): ?>
        <option value="<?php echo e($sector->id); ?>" selected><?php echo e($sector->nombre); ?></option>
      <?php else: ?>
        <option value="<?php echo e($sector->id); ?>"><?php echo e($sector->nombre); ?></option>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <label for="Sector">Selecciona un Sector</label>
</div>
<?php $__errorArgs = ['idSector'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<div class="form-floating mb-3">
  <textarea id="Descripcion" name="descripcion" class="form-control" placeholder="Descripción" style="height: 100px"><?php echo e($subsector->descripcion); ?></textarea>
  <label for="Descripcion">Descripción</label>
</div>
<?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  <span class="invalid-feedback" role="alert">
    <strong><?php echo e($message); ?></strong>
  </span>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="text-center mt-2">
    <button class="btn btn-outline-primary btn-sm"><?php echo e(empty($subsector->id) ? "Crear" : "Actualizar"); ?></button>
</div>
<?php echo csrf_field(); ?><?php /**PATH /var/www/html/salud/salud/resources/views/formSubsector.blade.php ENDPATH**/ ?>