@extends('layout')

@section('title', 'Acerca de Nosotros')

@section('styles')
  <style>
    h1, h2, h3, h4, h5, h6 {
      color: #007bff;
    }
  </style>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
@endsection

@section('content')
  <h1 class="">Sustancias</h1>
  <!--  -->
  <section class="my-3">
    <h2 class="fs-3">Tabla de Sustancias</h2>
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">Nombre</th>
        </tr>
      </thead>
      <tbody>
        @foreach($sustancias as $sustancia)
          <tr>
            <td>{{$sustancia->nombre}}</td>
          </tr>
        @endforeach
      </tbody>
    </table>

    <table id="myTable" class="display">
      <thead>
        <tr>
          <th>Nombre</th>
        </tr>
      </thead>
      <tbody>
        @foreach($sustancias as $sustancia)
          <tr>
            <td>{{$sustancia->nombre}}</td>
          </tr>
        @endforeach
      </tbody>
    </table>

  </section>
@endsection

@section('scriptsTables')
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
  <script>$("#myTable").DataTable();</script>
@endsection
